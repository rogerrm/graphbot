# Help

List of possible commands:

- `/start` 

    Starts the communication with the bot. No other command can be executed before it.

- `help`

    Shows
